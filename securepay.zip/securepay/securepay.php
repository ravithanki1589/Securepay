<!doctype html>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">	
</head>
<body>
<form onsubmit="return false;">
    <div id="securepay-ui-container"></div>
    <div id="loading-ui" style="display: none">Loading...</div>
    <button class="securepay-btn" onclick="mySecurePayUI.tokenise();">Submit</button>
    <button class="securepay-btn" onclick="mySecurePayUI.reset();">Reset</button>
</form>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script id="securepay-ui-js" src="https://payments-stest.npe.auspost.zone/v3/ui/client/securepay-ui.min.js"></script>
<script type="text/javascript">
    var mySecurePayUI = new securePayUI.init({
        containerId: 'securepay-ui-container',
        scriptId: 'securepay-ui-js',
        clientId: '0oaxb9i8P9vQdXTsn3l5',
        merchantCode: '5AR0055',
        card: { // card specific config and callbacks
            onTokeniseSuccess: function (tokenisedCard) {
			
				
                // card was successfully tokenised
                var data = tokenisedCard;
                var token = data.token;
                var obj = {
                    token: token
                };
				
				
				window.location.href = 'redirect.php?token='+token;
				
                $.post('success.php', obj, function (response) {
                    if (response != '') {
                        console.log(response);
                        $('#securepay-ui-container').hide();
                        $('.securepay-btn').hide();
                        $('#loading-ui').css('display', 'block');
                    }
                });
            }
        },
        onLoadComplete: function () {
            // the SecurePay UI Component has successfully loaded and is ready to be interacted with
        }
    });
</script>
</body>
</html>