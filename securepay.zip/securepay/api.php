<?php
	
$clientId     = '0oaxb9i8P9vQdXTsn3l5';	
$clientSecret = '0aBsGU3x1bc-UIF_vDBA2JzjpCPHjoCP7oI6jisp';	
$merchantCode = '5AR0055';	

//$token    = '2608848300559666'; //$_POST['token'];
//$amount   = 100; //$_POST['amount'];
//$currency = 'USD'; //$_POST['currency'];

$responseInput = json_decode(file_get_contents('php://input'), true);

$token    = $responseInput['token'];
$amount   = $responseInput['amount'];
$currency = $responseInput['currency'];
$ipaddress = $responseInput['ipaddress'];

$tokenPath = 'https://welcome.api2.sandbox.auspost.com.au/oauth/token';
$path = 'https://payments-stest.npe.auspost.zone/v2/payments';

$base64string = base64_encode($clientId.':'.$clientSecret);

$headers = array(
	"Authorization: Basic ".$base64string,
	"Content-Type: application/x-www-form-urlencoded"
);

$PT_payload  = "grant_type=client_credentials&audience=https://api.payments.auspost.com.au";

$ch = curl_init();
curl_setopt($ch,CURLOPT_URL, $tokenPath); 
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch,CURLOPT_POSTFIELDS, $PT_payload);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true); 
//execute post
$result = curl_exec($ch); //close connection
curl_close($ch);

$tokenResult = json_decode($result);

if($tokenResult->access_token != ''){
	
	$post['amount'] = $amount;
	$post['merchantCode'] = $merchantCode;
	$post['token'] = $token;
	$post['ip'] = $ipaddress;

	$payload = json_encode($post);

	$headers = array(
		"Content-Type: application/json",
		"Authorization: Bearer ".$tokenResult->access_token,
	);

	$ch = curl_init();
	curl_setopt($ch,CURLOPT_URL, $path); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch,CURLOPT_POSTFIELDS, $payload);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true); 
	//execute post
	$result = curl_exec($ch); //close connection
	curl_close($ch);

	$paymentResult = json_decode($result);
	echo $result;
}
else{
	
	$response['error'] = 'Access token not found';
	echo json_encode($response);
}
?>