<?php
echo $_POST['token'];
?>